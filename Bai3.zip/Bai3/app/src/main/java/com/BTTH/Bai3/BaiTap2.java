/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BTTH.Bai3;

/**
 *
 * @author Huy
 */
public class BaiTap2 {
    public static void main(String[] args) {
        HinhChuNhat hcn = new HinhChuNhat(4, 2);
        System.out.println(hcn);
        HinhChuNhat hv = new HinhVuong(4);
        System.out.println(hv);
    }
}
